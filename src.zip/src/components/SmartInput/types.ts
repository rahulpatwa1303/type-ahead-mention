export type { SmartInputConfig, SuggestionNode } from '../..';
